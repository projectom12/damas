$( document ).ready(function() {
    $('#exampleModal').modal('show')
});

var partida = new Partida();
var tabla = new Tauler();
var fitxa = new Fitxa();






